<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.3" name="map_village_tile6" tilewidth="40" tileheight="40" tilecount="64" columns="16">
 <image source="../Map/map_village_tile6.png" width="640" height="160"/>
</tileset>
