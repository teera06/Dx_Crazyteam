<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.3" name="map_camp_tile4" tilewidth="40" tileheight="40" tilecount="1" columns="1">
 <image source="../Map/map_camp_tile4.png" width="40" height="40"/>
</tileset>
